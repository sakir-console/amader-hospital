<template>
   <Layout></Layout>

</template>

<script>
import Layout from "@/views/frontend/Layout";
export default {
  components: {Layout}
}

</script>


