<template>
  <div>
    <div class="breadcrumb-bar">
      <div class="container-fluid">
        <div class="row align-items-center">
          <div class="col-md-12 col-12">

            <h2 class="breadcrumb-title">My Profile</h2>
          </div>
        </div>
      </div>
    </div>
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <sidebar></sidebar>




        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Sidebar from "@/components/frontend/sidebar";
export default {
name: "blank"
}
</script>

<style scoped>

</style>