<template>

  <div>
    <div class="breadcrumb-bar">
      <div class="container-fluid">
        <div class="row align-items-center">
          <div class="col-md-12 col-12">

            <h2 class="breadcrumb-title">My Appointment list</h2>

          </div>
        </div>
      </div>
    </div>
    <div class="content">
      <div class="container-fluid">
        <div class="row">

          <patSidebar></patSidebar>

          <div class="col-md-7 col-lg-8 col-xl-9">

            <div class="row">
              <div class="col-md-12">
                <h4 class="mb-4">Patients Appointment</h4>
                <div class="appointment-tab">


                  <div class="tab-content">

                    <div class="tab-pane show active" id="upcoming-appointments">
                      <div class="card card-table mb-0">
                        <div class="card-body">
                          <div class="table-responsive">
                            <table class="table table-hover table-center mb-0">
                              <thead>
                              <tr>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Appoint date</th>
                                <th>Serial</th>
                                <th>Schedule start</th>
                              </tr>
                              </thead>
                              <tbody>
                              <tr v-for="(appointment,index) in appointments.data" :key="appointment.id" :value="appointment.id">
                                <td>
                                  <h2 class="table-avatar">
                                    {{appointment.patient}}

                                  </h2>
                                </td>
                                <td>{{appointment.status}}</td>
                                <td>{{appointment.a_date}}</td>
                                <td>{{appointment.serial}}</td>
                                <td class="text-center">{{appointment.sch_start}}</td>

                              </tr>

                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>


                  </div>
                </div>
              </div>
            </div>
            <div>
              <ul class="pagination mb-4">
                <li class="page-item disabled">
                  <a class="page-link" href="#" tabindex="-1">Pages:</a>
                </li>
                <li v-for="index in appointments['maxPage']" :key="index" :class="[(page == index) ? 'active':'']">
                  <a style="color: white;font-weight: 900;" class="page-link" href="#" @click="nextPage(index)">{{ index }}</a>
                </li>

              </ul>
            </div>

          </div>

        </div>
      </div>
    </div>
  </div>
</template>

<script>
import patSidebar from "@/components/frontend/patSidebar";
export default {
  name: "patAppointments",
  components: {patSidebar},
  data() {
    return {
      page: 1,
      id: '',
      name: '',
      appointments: []
    }
  },
  methods: {
    //   FETCH request - AH

    appointmentsView() {

      this.loading = true;

      //request - AH
      this.axios.get("appointment/"+this.page)
          .then(response => {
            this.loading = false;
            this.appointments=response.data
            if (response.data.data.length !== 0) {
              this.NoData = false
            } else {
              this.NoData = true
            }
            console.log((response.data))
            this.bloods = response.data
          })
          .catch(error => {
            this.errorMessage = error.message;
            console.error("There was an error!", error);
          });
    },
    nextPage(pg) {
      this.page = pg
      this.appointmentsView()
    },
  },
  mounted() {
    this.appointmentsView()
  }
}
</script>

<style scoped>

</style>