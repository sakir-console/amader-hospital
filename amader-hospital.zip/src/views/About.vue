<template>
  <div class="about">
    <h1>{{$t('about_page')}}</h1>
  </div>
</template>
