<template>
<div>

  <div class="content success-page-cont">
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-lg-6">

          <div class="card success-card">
            <div class="card-body">
              <div class="success-cont">
                <i class="fa fa-warehouse"></i>
                <h3>Not Found</h3>
                <p>  <strong>Sorry!</strong> Page not found</p>
                <a href="/" class="btn btn-primary view-inv-btn">Back to Home</a>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

</div>
</template>

<script>
export default {
name: "notFound"
}
</script>

<style scoped>

</style>