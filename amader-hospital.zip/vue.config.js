module.exports = {
    devServer: {
        proxy: 'https://amaderhospital.com/api/',
    }
}